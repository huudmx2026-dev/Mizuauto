# Mizuauto source export

Current WinForms frontend and Rust backend: `upstream-ram-372/`.
Earlier Python prototype: `roblox_optimizer.py`, `ram_integration.py`, and related files at the archive root.

This snapshot includes current working-tree edits, including files not yet committed to Git.
Local account data, cookies, personal settings, build outputs, dependency caches, Git history, and the original upstream release workflow are excluded.

Build instructions: `upstream-ram-372/README_HYBRID.md` and `upstream-ram-372/mizuauto-rust/README_BUILD.md`.
Upstream license: `upstream-ram-372/LICENSE` (GPL-3.0).
